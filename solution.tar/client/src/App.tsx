import "destyle.css";
import React from "react";

const App: React.FC = () => {
  return <div>list of RATS That should stay away from my DAMN BINS</div>;
};

export default App;
